public interface Player {
	public void playTurn(Board board, Mark mark);
}
