bashar.rashed
213541097

Ori: what 

Alex: whaaat what 

Ori: say what I should say whaaat what 

Alex: whatever you say: 

Ori: say what I should say whatever you say: 

Alex: whatever you say: what I should say whatever you say:

Ori: say what I should say whatever you say: what I should say whatever you say:

Alex: pfft okay:

Ori: say what I should say

Alex: pfft okay: what I should say

Ori: what pfft okay: what I should say
